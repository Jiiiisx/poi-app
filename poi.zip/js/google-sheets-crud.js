class GoogleSheetsCRUD {
    constructor() {
        this.spreadsheetId = CONFIG.SPREADSHEET_ID;
        this.apiKey = CONFIG.API_KEY;
        this.sheetName = 'REKAP CALON PELANGGAN BY SPARTA';
        this.clientId = CONFIG.CLIENT_ID;
        
        console.log('🚀 Google Sheets CRUD instance created');
    }

    // CREATE - Menambah data baru
    async addCustomer(customerData) {
        try {
            await ensureAuthenticatedGapiClient();
            console.log('➕ Adding new customer...', customerData);
            
            const range = `${this.sheetName}!A:H`;
            const values = [[
                customerData.odp_terdekat || '',
                customerData.nama || '',
                customerData.alamat || '',
                customerData.no_telepon || '',
                customerData.nama_sales || '',
                customerData.visit || 'Not Visited',
                customerData.status || 'Pending',
                customerData.keterangan_tambahan || ''
            ]];

            const request = {
                spreadsheetId: this.spreadsheetId,
                range: range,
                valueInputOption: 'USER_ENTERED',
                resource: {
                    values: values
                }
            };

            const response = await gapi.client.sheets.spreadsheets.values.append(request);
            console.log('✅ Customer added successfully:', response.result);
            NotificationHandler.show('Customer added successfully!', 'success');
            return response.result;

        } catch (error) {
            console.error('❌ Add customer error:', error);
            ModalHandler.show('Error', `Failed to add data: ${error.message}`);
            throw new Error(`Gagal menambah data: ${error.message}`);
        }
    }

    // READ - Membaca data dari spreadsheet
    async readData() {
        try {
            console.log('📖 Reading data from spreadsheet...');
            
            const range = `${this.sheetName}!A1:H1000`;
            const response = await gapi.client.sheets.spreadsheets.values.get({
                spreadsheetId: this.spreadsheetId,
                range: range
            });

            const values = response.result.values || [];
            console.log('✅ Data read successfully:', values.length, 'rows');
            return values;

        } catch (error) {
            console.error('❌ Read data error:', error);
            throw new Error(`Gagal membaca data: ${error.message}`);
        }
    }

    // READ - Membaca data dari sheet tertentu
    async readSheet(sheetName, range) {
        try {
            await ensureAuthenticatedGapiClient();
            console.log(`📖 Reading data from sheet: ${sheetName}, range: ${range}...`);
            
            const response = await gapi.client.sheets.spreadsheets.values.get({
                spreadsheetId: this.spreadsheetId,
                range: `${sheetName}!${range}`
            });

            const values = response.result.values || [];
            console.log(`✅ Data read successfully from ${sheetName}:`, values.length, 'rows');
            return values;

        } catch (error) {
            console.error(`❌ Read sheet (${sheetName}) error:`, error);
            throw new Error(`Gagal membaca data dari sheet ${sheetName}: ${error.message}`);
        }
    }

    // UPDATE - Mengupdate data yang sudah ada
    async updateCustomer(rowIndex, customerData) {
        try {
            await ensureAuthenticatedGapiClient();
            console.log('✏️ Updating customer at row:', rowIndex);
            
            // Row index + 2 karena header di baris 1 dan index 0-based
            const actualRow = rowIndex + 2;
            const range = `${this.sheetName}!A${actualRow}:H${actualRow}`;
            
            const values = [[
                customerData.odp_terdekat || '',
                customerData.nama || '',
                customerData.alamat || '',
                customerData.no_telepon || '',
                customerData.nama_sales || '',
                customerData.visit || 'Not Visited',
                customerData.status || 'Pending',
                customerData.keterangan_tambahan || ''
            ]];

            const request = {
                spreadsheetId: this.spreadsheetId,
                range: range,
                valueInputOption: 'USER_ENTERED',
                resource: {
                    values: values
                }
            };

            const response = await gapi.client.sheets.spreadsheets.values.update(request);
            console.log('✅ Customer updated successfully:', response.result);
            NotificationHandler.show('Customer updated successfully!', 'success');
            return response.result;

        } catch (error) {
            console.error('❌ Update customer error:', error);
            ModalHandler.show('Error', `Failed to update data: ${error.message}`);
            throw new Error(`Gagal update data: ${error.message}`);
        }
    }

    // DELETE - Menghapus data
    async deleteCustomer(rowIndex) {
        ModalHandler.show(
            'Confirm Deletion',
            'Are you sure you want to delete this customer?',
            async () => {
                try {
                    const token = await ensureAuthenticatedGapiClient();
                    console.log('🗑️ Deleting customer at row:', rowIndex);

                    // Get the correct sheetId dynamically
                    const sheetId = await this.getSheetIdByName(this.sheetName);
                    if (sheetId === null) {
                        throw new Error('Tidak dapat menemukan sheet ID untuk sheet: ' + this.sheetName);
                    }

                    // Debug logs for verification
                    console.log(`Sheet Name: ${this.sheetName}, Sheet ID: ${sheetId}`);
                    console.log(`Requested row index to delete: ${rowIndex}`);
                    const actualRow = rowIndex + 2; 
                    console.log(`Calculated actual row in sheet: ${actualRow}`);

                    const url = `https://sheets.googleapis.com/v4/spreadsheets/${this.spreadsheetId}:batchUpdate`;

                    const requestBody = {
                        requests: [{
                            deleteDimension: {
                                range: {
                                    sheetId: sheetId, 
                                    dimension: 'ROWS',
                                    startIndex: actualRow - 1,
                                    endIndex: actualRow
                                }
                            }
                        }]
                    };

                    const response = await fetch(url, {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${token.access_token}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(requestBody)
                    });

                    const responseData = await response.json();

                    if (!response.ok) {
                        throw new Error(responseData.error.message || 'Failed to delete row via Google Sheets API');
                    }

                    console.log('✅ Customer deleted successfully:', responseData);
                    NotificationHandler.show('Data berhasil dihapus!', 'success');

                    // Refresh data after deletion to update UI
                    if (window.googleSheetsIntegration && typeof window.googleSheetsIntegration.refreshData === 'function') {
                        await window.googleSheetsIntegration.refreshData();
                    }

                    return responseData;

                } catch (error) {
                    console.error('❌ Delete customer error:', error);
                    ModalHandler.show('Error', `Failed to delete data: ${error.message}`);
                    throw new Error(`Gagal menghapus data: ${error.message}`);
                }
            }
        );
    }

    // Batch operations untuk efisiensi
    async batchUpdate(updates) {
        try {
            await ensureAuthenticatedGapiClient();
            console.log('📊 Performing batch update...', updates.length, 'updates');
            
            const requests = updates.map(update => ({
                updateCells: {
                    range: {
                        sheetId: 0,
                        startRowIndex: update.rowIndex + 1,
                        endRowIndex: update.rowIndex + 2,
                        startColumnIndex: 0,
                        endColumnIndex: 8
                    },
                    rows: [{
                        values: update.values.map(value => ({
                            userEnteredValue: { stringValue: value }
                        }))
                    }],
                    fields: 'userEnteredValue'
                }
            }));

            const request = {
                spreadsheetId: this.spreadsheetId,
                resource: { requests }
            };

            const response = await gapi.client.sheets.spreadsheets.batchUpdate(request);
            console.log('✅ Batch update completed:', response.result);
            return response.result;

        } catch (error) {
            console.error('❌ Batch update error:', error);
            throw new Error(`Gagal batch update: ${error.message}`);
        }
    }

    async getSheetInfo() {
        try {
            await ensureAuthenticatedGapiClient();
            const response = await gapi.client.sheets.spreadsheets.get({
                spreadsheetId: this.spreadsheetId
            });
            return response.result;
        } catch (error) {
            console.error('❌ Get sheet info error:', error);
            throw error;
        }
    }

    async getSheetIdByName(sheetName) {
        try {
            const sheetInfo = await this.getSheetInfo();
            const sheet = sheetInfo.sheets.find(s => s.properties.title === sheetName);
            return sheet ? sheet.properties.sheetId : null;
        } catch (error) {
            console.error('❌ Get sheet ID error:', error);
            throw error;
        }
    }

    // Error handling
    handleError(error, context) {
        console.error(`❌ Error in ${context}:`, error);
        const errorMessage = error.message || 'Terjadi kesalahan yang tidak diketahui';
        
        // Tampilkan error ke user
        const errorDiv = document.getElementById('errorDisplay');
        if (errorDiv) {
            errorDiv.innerHTML = `
                <div class="alert alert-danger" style="margin: 20px; padding: 15px; border-radius: 5px;">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Error:</strong> ${errorMessage}
                    <button onclick="this.parentElement.parentElement.style.display='none'" 
                            style="float: right; background: none; border: none; font-size: 20px;">
                        &times;
                    </button>
                </div>
            `;
            errorDiv.style.display = 'block';
        }
        
        return errorMessage;
    }

    // Validation functions
    validateCustomerData(data) {
        const required = ['nama', 'no_telepon', 'alamat', 'odp_terdekat', 'nama_sales'];
        const missing = required.filter(field => !data[field] || data[field].trim() === '');
        
        if (missing.length > 0) {
            throw new Error(`Field wajib tidak lengkap: ${missing.join(', ')}`);
        }
        
        // Validasi nomor telepon
        if (!/^[0-9]{10,13}$/.test(data.no_telepon)) {
            throw new Error('Nomor telepon harus 10-13 digit angka');
        }
        
        return true;
    }

    // Helper untuk konversi data
    convertToSheetFormat(data) {
        return [
            data.odp_terdekat || '',
            data.nama || '',
            data.alamat || '',
            data.no_telepon || '',
            data.nama_sales || '',
            data.visit || 'Not Visited',
            data.status || 'Pending',
            data.keterangan_tambahan || ''
        ];
    }

    // Test connection
    async testConnection() {
        try {
            console.log('🧪 Testing Google Sheets connection...');
            await this.readData();
            console.log('✅ Connection test successful');
            return true;
        } catch (error) {
            console.error('❌ Connection test failed:', error);
            return false;
        }
    }
}



// Global functions untuk digunakan di UI
window.addCustomer = async function(customerData) {
    if (!googleSheetsCRUD) {
        throw new Error('Google Sheets CRUD belum diinisialisasi');
    }
    return await googleSheetsCRUD.addCustomer(customerData);
};

window.updateCustomer = async function(rowIndex, customerData) {
    if (!googleSheetsCRUD) {
        throw new Error('Google Sheets CRUD belum diinisialisasi');
    }
    return await googleSheetsCRUD.updateCustomer(rowIndex, customerData);
};

window.deleteCustomer = async function(rowIndex) {
    if (!googleSheetsCRUD) {
        throw new Error('Google Sheets CRUD belum diinisialisasi');
    }
    return await googleSheetsCRUD.deleteCustomer(rowIndex);
};

window.testSheetsConnection = async function() {
    if (!googleSheetsCRUD) {
        throw new Error('Google Sheets CRUD belum diinisialisasi');
    }
    return await googleSheetsCRUD.testConnection();
};

const googleSheetsCRUD = new GoogleSheetsCRUD();

document.dispatchEvent(new CustomEvent('crudReady'));
window.googleSheetsCRUD = googleSheetsCRUD;

